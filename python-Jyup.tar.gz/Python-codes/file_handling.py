# File Handling
f=open("/Users/zerocool/file_handling.txt","w")
f.write("Hello")
f.close()